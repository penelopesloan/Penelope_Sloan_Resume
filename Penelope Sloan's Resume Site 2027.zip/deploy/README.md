# Penelope Sloan — CV site

Static site (`index.html`) plus one Netlify Function (`netlify/functions/chat.js`) that powers the "Ask about my experience" chat via the Claude API.

## Deploy
1. Push this folder to a GitHub repo.
2. In Netlify: Add new site → Import from GitHub → pick the repo. No build command needed.
3. Netlify → Site settings → Environment variables → add `ANTHROPIC_API_KEY` (from console.anthropic.com).
4. Redeploy. The chat now works on the live site.

## Updating
Edit the design in the editor, re-export `index.html`, replace it here, and push.
